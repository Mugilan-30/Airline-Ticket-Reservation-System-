app.post('/booking', async (req, res) => {
    const booking = new Booking(req.body);

    await booking.save();

    res.send("Ticket booked successfully");
});
