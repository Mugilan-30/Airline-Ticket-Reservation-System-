app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    const user = await User.findOne({ email });

    if (!user)
        return res.send("User not found");

    if (user.password === password)
        res.json({
            message: "Login successful",
            role: user.role
        });
    else
        res.send("Invalid password");
});
