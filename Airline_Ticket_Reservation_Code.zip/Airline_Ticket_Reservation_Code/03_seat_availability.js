app.get('/seats/:flightId', async (req, res) => {
    const flight = await Flight.findById(req.params.flightId);

    if (flight.availableSeats > 0)
        res.json({ available: true });
    else
        res.send("No seats available");
});
