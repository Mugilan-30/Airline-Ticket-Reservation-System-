app.post('/payment', async (req, res) => {
    const { bookingId, amount } = req.body;

    if (amount > 0)
        res.json({
            message: "Payment successful",
            bookingId
        });
    else
        res.send("Payment failed");
});
