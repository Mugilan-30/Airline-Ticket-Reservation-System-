app.get('/flights', async (req, res) => {
    const { source, destination, date } = req.query;

    const flights = await Flight.find({
        source,
        destination,
        date
    });

    res.json(flights);
});
