app.post('/flight', async (req, res) => {
    const flight = new Flight(req.body);

    await flight.save();

    res.send("Flight added successfully");
});
