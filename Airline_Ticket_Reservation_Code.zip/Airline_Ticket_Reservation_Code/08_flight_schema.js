const flightSchema = new mongoose.Schema({
    flightNo: String,
    source: String,
    destination: String,
    date: String,
    time: String,
    availableSeats: Number
});

module.exports = mongoose.model('Flight', flightSchema);
